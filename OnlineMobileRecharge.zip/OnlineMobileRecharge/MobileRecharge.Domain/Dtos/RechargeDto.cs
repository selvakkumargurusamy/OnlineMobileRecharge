﻿namespace MobileRecharge.Domain.Dtos
{
    public class RechargeDto
    {
        public int BeneficiaryId { get; set; }

        public int Amount { get; set; }
    }
}

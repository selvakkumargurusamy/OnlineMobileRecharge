﻿global using Microsoft.EntityFrameworkCore;
global using MobileRecharge.Domain.Interfaces.Repositories;
global using MobileRecharge.Domain.Models;
global using MobileRecharge.Infrastructure.Database;
﻿namespace Payment.Api.Dto
{
    public class PaymentDto
    {
        public int UserId { get; set; }
        public int Amount { get; set; }
    }
}

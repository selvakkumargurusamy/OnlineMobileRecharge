﻿namespace MobileRecharge.Application.Queries;

public  class GetAllUsersQuery : IRequest<IEnumerable<UserDto>>
{

}
